const fs = require('fs');
const FILE_PATH = 'appointments.txt';

function saveAppointmentsToFile(appointments) {
  fs.writeFileSync(FILE_PATH, JSON.stringify(appointments, null, 2));
}

function loadAppointmentsFromFile() {
  if (fs.existsSync(FILE_PATH)) {
    const data = fs.readFileSync(FILE_PATH, 'utf-8');
    return JSON.parse(data);
  }
  return [];
}

module.exports = { saveAppointmentsToFile, loadAppointmentsFromFile };
