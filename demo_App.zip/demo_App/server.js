const { saveAppointmentsToFile, loadAppointmentsFromFile } = require('./appointments'); // Import the functions


const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const http=require('http')
const server = http.createServer((req, res) => {
    if (req.url === '/' && req.method === 'GET') {
       
        const filePath = path.join(__dirname, '/public/index.html'); 
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end('Error loading index.html');
                return;
            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data);
        });
    } else{
        otherFunction(req,res)
    }
});
function otherFunction(req,res){
    if (req.url === '/submit-booking') {
        handleBooking(req, res);     
    } else if (req.url === '/modify-appoinment') {
        handleModifyAppointment(req, res);      
    }else if (req.url === '/cancel-appoinment') {
        cancelBooking(req, res);      
    }

}


function cancelBooking(req, res) {
    let body = '';
    req.on('data', chunk => {
        body += chunk.toString(); 
    });

    req.on('end', () => {
        const formData = new URLSearchParams(body);
        const phone = formData.get('phone'); 

        let appointments = loadAppointmentsFromFile();

        const existingIndex = appointments.findIndex(a => a.phone === phone);
        if (existingIndex !== -1) {
            appointments.splice(existingIndex, 1);

            saveAppointmentsToFile(appointments);

            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Booking Response</title>
                    <script>
                        alert('Appointment booked/modified successfully!');
                        window.location.href = '/'; 
                    </script>
                </head>
                <body>
                </body>
                </html>
            `);
        } else {
        
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Booking Response</title>
                    <script>
                        alert('No appointment found for the provided phone number.');
                        window.location.href = '/'; 
                    </script>
                </head>
                <body>
                </body>
                </html>
            `);
          
        }
    });
}
function handleModifyAppointment(req, res) {
    let body = '';
    req.on('data', chunk => {
        body += chunk.toString(); 
    });

    req.on('end', () => {
        const formData = new URLSearchParams(body);

        const updatedData = {
            service: formData.get('service'),
            date: formData.get('date'),
            time: formData.get('time'),
            notes: formData.get('notes'),
        };

        // Load existing appointments from the file
        let appointments = loadAppointmentsFromFile();

        const existingIndex = appointments.findIndex(a => a.phone === formData.get('phone'));
        if (existingIndex !== -1) {
            const existingAppointment = appointments[existingIndex];

            
            if (updatedData.service) existingAppointment.service = updatedData.service;
            if (updatedData.date) existingAppointment.date = updatedData.date;
            if (updatedData.time) existingAppointment.time = updatedData.time;
            if (updatedData.notes) existingAppointment.notes = updatedData.notes;

        
            saveAppointmentsToFile(appointments);

            res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Booking Response</title>
                <script>
                    alert('Appointment modified successfully!');
                    window.location.href = '/'; 
                </script>
            </head>
            <body>
            </body>
            </html>
        `);
        } else {
            res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Booking Response</title>
                <script>
                    alert('No Booking Found');
                    window.location.href = '/'; 
                </script>
            </head>
            <body>
            </body>
            </html>
        `);
        }
    });
}

function handleBooking(req, res) {
    let body = '';
    req.on('data', chunk => {
        body += chunk.toString(); 
    });

    req.on('end', () => {
        const formData = new URLSearchParams(body);
        const appointment = {
            name: formData.get('name'),
            phone: formData.get('phone'),
            service: formData.get('service'),
            date: formData.get('date'),
            time: formData.get('time'),
            notes: formData.get('notes'),
        };

        let appointments = loadAppointmentsFromFile();

        const existingIndex = appointments.findIndex(a => a.phone === appointment.phone);
        if (existingIndex !== -1) {
            appointments[existingIndex] = appointment;
        } else {
            appointments.push(appointment);
        }

        saveAppointmentsToFile(appointments);

        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Booking Response</title>
                <script>
                    alert('Appointment booked/modified successfully!');
                    window.location.href = '/'; 
                </script>
            </head>
            <body>
            </body>
            </html>
        `);
    });
}



app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));


server.listen(3030)



